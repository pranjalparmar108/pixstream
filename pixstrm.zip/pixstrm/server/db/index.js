const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize("pixstream", "root", "", {
    host: "127.0.0.1",
    port: '3306',
    dialect: 'mysql',
  });
  
  
sequelize.authenticate().then(() => {
    console.log('Connected to database');
  }).catch((e) => {
    console.log(e);
  })
  
  const db = {};

  db.sequelize = sequelize;
  db.Sequelize = Sequelize;
  db.users = require('../models/User')(sequelize, DataTypes);
  db.doctors = require("../models/Post")(sequelize, DataTypes);  