const express = require('express');
const { Sequelize } = require('sequelize');
const app = express();
const PORT = 2000;

// Setup Sequelize
const sequelize = new Sequelize('database_name', 'username', 'password', {
    host: 'localhost',
    dialect: 'mysql', // or 'mysql', 'postgres', 'sqlite', etc.
});

// Test Sequelize connection
sequelize.authenticate()
    .then(() => {
        console.log('Database connected successfully');
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });

// Import models after defining Sequelize
const Post = require('./models/Post');
const User = require('./models/User');

// Middleware
app.use(express.json());
app.use(require('./routes/auth.route'));
app.use(require('./routes/post.route'));

// Custom middleware
const customMiddleware = (req, res, next) => {
    console.log("Custom middleware");
    next();
};

// Routes
app.get('/', (req, res) => {
    console.log("Home");
    res.send("Hello World");
});

app.get('/about', customMiddleware, (req, res) => {
    console.log("About page");
    res.send("About page");
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
