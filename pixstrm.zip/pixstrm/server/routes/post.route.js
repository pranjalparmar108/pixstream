const express = require('express');
const Post = require('../models/Post'); // Assuming you have Post and User models defined in models
const User = require('../models/User');

const requiredLogin = require('../middlewares/requiredLogin');
const router = express.Router();

// Get all posts
router.get('/allposts', requiredLogin, async (req, res) => {
    try {
        const posts = await Post.findAll({
            include: {
                model: User,
                attributes: ['id', 'name'],
                as: 'postedBy'
            }
        });
        res.json(posts);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Get posts by the logged-in user
router.get('/mypost', requiredLogin, async (req, res) => {
    try {
        const posts = await Post.findAll({
            where: { postedBy: req.user.id },
            include: {
                model: User,
                as: 'postedBy'
            }
        });
        res.json(posts);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Create a new post
router.post('/createPost', requiredLogin, async (req, res) => {
    const { title, body, pic } = req.body;
    if (!title || !body || !pic) {
        return res.status(400).json({ error: "Please fill all fields" });
    }

    try {
        const post = await Post.create({
            title,
            body,
            photo: pic,
            postedBy: req.user.id
        });
        res.json({ post });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Like a post
router.put('/like', requiredLogin, async (req, res) => {
    const { postId } = req.body;

    try {
        const post = await Post.findByPk(postId);
        if (!post) {
            return res.status(404).json({ error: "Post not found" });
        }

        const updatedPost = await post.update({
            likes: Sequelize.fn('array_append', Sequelize.col('likes'), req.user.id)
        });

        res.json(updatedPost);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Unlike a post
router.put('/unlike', requiredLogin, async (req, res) => {
    const { postId } = req.body;

    try {
        const post = await Post.findByPk(postId);
        if (!post) {
            return res.status(404).json({ error: "Post not found" });
        }

        const updatedPost = await post.update({
            likes: Sequelize.fn('array_remove', Sequelize.col('likes'), req.user.id)
        });

        res.json(updatedPost);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// Comment on a post
router.put('/comment', requiredLogin, async (req, res) => {
    const { postId, comment } = req.body;

    try {
        const post = await Post.findByPk(postId);
        if (!post) {
            return res.status(404).json({ error: "Post not found" });
        }

        const updatedPost = await post.update({
            comments: Sequelize.fn('jsonb_set', Sequelize.col('comments'), 
                `{${post.comments.length}}`, 
                JSON.stringify({ text: comment, postedBy: req.user.id }), 
                true)
        });

        res.json(updatedPost);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

module.exports = router;
