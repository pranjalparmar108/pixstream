const express = require('express');
const db = require("../db/index");
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../keys');
const { User } = require('../models'); // Assuming you have a User model defined in models
const requiredLogin = require('../middlewares/requiredLogin');

// Middleware to verify token
router.get('/protected', requiredLogin, (req, res) => {
    res.send("hello user");
});

// User Register
router.post('/signUp', async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(404).json({ error: "Please enter all fields" });
    }

    try {
        const savedUser = await User.findOne({ where: { email: email } });
        
        if (savedUser) {
            return res.status(409).json({ error: "User already exists with this email" });
        }

        const hashedPassword = await bcrypt.hash(password, 12);
        const newUser = await User.create({ name, email, password: hashedPassword });

        res.json({ message: "User created successfully", user: newUser });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

// User Login
router.post('/signIn', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "Please fill all the required fields" });
    }

    try {
        const savedUser = await User.findOne({ where: { email: email } });

        if (!savedUser) {
            return res.status(422).json({ error: "Invalid email or password" });
        }

        const doMatch = await bcrypt.compare(password, savedUser.password);

        if (doMatch) {
            const token = jwt.sign({ id: savedUser.id }, JWT_SECRET);
            const { id, name, email } = savedUser;
            res.json({ token, user: { id, name, email } });
        } else {
            res.status(422).json({ message: "Invalid password" });
        }
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
    }
});

module.exports = router;
