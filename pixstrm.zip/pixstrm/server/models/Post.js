module.exports = (sequelize, DataTypes) => {
    const Post = sequelize.define("Post", {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      title: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      body: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      photo: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      postedBy: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Users",
          key: "id",
        },
      },
      likes: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
        references: {
          model: "Users",
          key: "id",
        },
        defaultValue: [],
      },
      comments: {
        type: DataTypes.JSONB,
        defaultValue: [],
      },
    });
  
    return Post;
  };
  