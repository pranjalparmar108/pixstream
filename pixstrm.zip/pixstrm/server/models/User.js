module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define("Users", {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
          isEmail: true,
        },
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      followers: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      },
      following: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      },
      profileImage: {
        type: DataTypes.STRING,
      },
    });
  
    return User;
  };
  