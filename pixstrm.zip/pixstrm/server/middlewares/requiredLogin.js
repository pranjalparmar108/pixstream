const jwt = require('jsonwebtoken');
const db = require("../db/index");
const { JWT_SECRET } = require('../keys');
const { User } = require('../models'); // Assuming you have a User model defined in models

module.exports = async (req, res, next) => {
  const { authorization } = req.headers;

  if (!authorization) {
    return res.status(401).json({ error: "You must be logged in" });
  }

  const token = authorization;
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const { id } = payload;

    // Fetch the user by id using Sequelize
    const userdata = await User.findByPk(id);

    if (!userdata) {
      return res.status(401).json({ error: "You must be logged in" });
    }

    req.user = userdata;
    next();
  } catch (err) {
    return res.status(401).json({ error: "You must be logged in" });
  }
};
